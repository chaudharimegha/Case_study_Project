export class TrainModel{

    TrainId :number;
    TrainName:string;
    TrainType:string;
    From:string;
    TO:string;
    ArrivalTime:string;
    DepartureTime:string;
    Distance: string;
    TrainCharges:number;
}