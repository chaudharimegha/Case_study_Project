import { BookingDetails } from './booking-details.model';

describe('BookingDetails', () => {
  it('should create an instance', () => {
    expect(new BookingDetails()).toBeTruthy();
  });
});