export class RegisterModel {
    PassengerId: number;
    FirstName: string;
    LastName: string;
    EmailId: string;
    Password: string;
    Gender: string;
    Age: string;
    MobileNumber: string ;
    
}