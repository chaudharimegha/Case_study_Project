import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticketgeneration',
  templateUrl: './ticketgeneration.component.html',
  styleUrls: ['./ticketgeneration.component.css']
})
export class TicketgenerationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
